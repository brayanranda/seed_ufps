/**
 * ---------------------------------------------------------------------
 * $Id: SimuladorArbolSplay.java,v 1.0 2013/08/23 
 * Universidad Francisco de Paula Santander 
 * Programa Ingenieria de Sistemas
 *
 * Proyecto: SEED_UFPS
 * ----------------------------------------------------------------------
 */

package Mundo_ArbolSplay;

import Colecciones_SEED.ArbolSplay;
import Graficos.ArbolSplayG;
import java.util.Iterator;

/**
 * Clase que conecta la capa de presentación del Simulador con las Estructuras de Datos.
 * @author Uriel Garcia - Yulieth Pabon
 * @version 1.0
 */

public class SimuladorArbolSplay {
    
    private ArbolSplay  miArbolSplay;
    
    public SimuladorArbolSplay(){
        this.miArbolSplay = new ArbolSplay();
    }
    
    public ArbolSplayG crearArbolSplayGrafico(ArbolSplayG n) {
        n.crearArbol(this.miArbolSplay.getRaiz());
        return (n);
    }

    public int conocerAltura() {
        return this.miArbolSplay.getAltura();
    }

    public int insertarDato(int dato) {
        ArbolSplay<Integer> clon = this.miArbolSplay.clonar();
        if(clon.estaAS(dato)){
            if(clon.getAltura()>5)
                return (-2);
            this.miArbolSplay.estaAS(dato);
            return (-1); //Dato repetido
        }          
        clon = this.miArbolSplay.clonar();
        if(clon.insertar(dato)){
            if(clon.getAltura()>5)
                return (-2); //Supera la altura 5
            this.miArbolSplay.insertar(dato);
            return (0); //Insercion correcta
        }
        return (-3); //No se pudo insertar
    }

    public boolean estaVacioArbol() {
        return (this.miArbolSplay.esVacio());
    }

    public int eliminarDato(int dato) {
        ArbolSplay<Integer> clon = this.miArbolSplay.clonar();
        clon.eliminar(dato);
        if(clon.getAltura()>5)
            return (-2);
        boolean x = this.miArbolSplay.eliminar(dato);        
        return (x==true?0:-1);
    }

    public int estaDatoenArbol(int dato) {
        ArbolSplay<Integer> clon = this.miArbolSplay.clonar();
        clon.estaAS(dato);
        if(clon.getAltura()>5)
            return (-2);
        boolean rta = this.miArbolSplay.estaAS(dato);
        return (rta==true?0:-1);
    }

    public int conocerPeso() {
        return (this.miArbolSplay.getPeso());
    }

    public int contarHojas() {
        return (this.miArbolSplay.contarHojas());
    }

    public String obtenerHojas() {
        Iterator<Integer> it = this.miArbolSplay.getHojas();
        String cad = "";
        while(it.hasNext()){
            cad+= it.next().toString();
            if(it.hasNext())
                cad+=", ";
            else
                cad+=".";
        }        
        return (cad);
    }

    public void podarHojas() {
        this.miArbolSplay.podar();
    }

    public String recorridoPreorden() {
        Iterator<Integer> it = this.miArbolSplay.preOrden();
        String cad = "";
        int i=0;
        while(it.hasNext()){
            cad+= it.next().toString();
            if(it.hasNext())
                cad+=", ";
            else
                cad+=".";
            if(i==15){
                cad+="\n";
            }
            i++;
        }        
        return (cad);
    }
    
    public String recorridoInorden() {
        Iterator<Integer> it = this.miArbolSplay.inOrden();
        String cad = "";
        int i=0;
        while(it.hasNext()){
            cad+= it.next().toString();
            if(it.hasNext())
                cad+=", ";
            else
                cad+=".";
            if(i==15){
                cad+="\n";
            }
            i++;
        }        
        return (cad);
    }
    
    public String recorridoPostorden() {
        Iterator<Integer> it = this.miArbolSplay.postOrden();
        String cad = "";
        int i=0;
        while(it.hasNext()){
            cad+= it.next().toString();
            if(it.hasNext())
                cad+=", ";
            else
                cad+=".";
            if(i==15){
                cad+="\n";
            }
            i++;
        }        
        return (cad);
    }
    
    public String recorridoPorNiveles() {
        Iterator<Integer> it = this.miArbolSplay.impNiveles();
        String cad = "";
        int i=0;
        while(it.hasNext()){
            cad+= it.next().toString();
            if(it.hasNext())
                cad+=", ";
            else
                cad+=".";
            if(i==15){
                cad+="\n";
            }
            i++;
        }        
        return (cad);
    }
    
    
    
}
