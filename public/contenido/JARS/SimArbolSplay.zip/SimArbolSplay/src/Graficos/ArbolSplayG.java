/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Graficos;


/**
 *
 * @author usuario
 */
public class ArbolSplayG extends ArbolBBG{

    public ArbolSplayG() {
        super();
    }
    
}
