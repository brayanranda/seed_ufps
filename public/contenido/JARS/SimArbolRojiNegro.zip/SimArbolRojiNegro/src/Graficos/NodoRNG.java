/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Graficos;

import javafx.scene.control.Label;
import javafx.scene.shape.Circle;

/**
 *
 * @author usuario
 */
public class NodoRNG extends NodoBinG {
    
    private int color;   

    public NodoRNG(int color, int info, Circle c, Label l, NodoRNG izq, NodoRNG der) {
        super(info, c, l, izq, der);
        this.color = color;
    }

    @Override
    public NodoRNG getIzq() {
        return (NodoRNG) super.getIzq();
    }

    public void setIzq(NodoRNG izq) {
        super.setIzq(izq);
    }

    @Override
    public NodoRNG getDer() {
        return (NodoRNG) super.getDer();
    }

    public void setDer(NodoRNG der) {
        super.setDer(der);
    }
    
    public int getColor() {
        return color;
    }

    public void setColor(int color) {
        this.color = color;
    }

    public void cargarLabel() {
        super.getL().setText(super.getInfo()+"");
    }
}
