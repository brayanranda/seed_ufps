/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Graficos;

import javafx.scene.control.Label;
import javafx.scene.shape.Rectangle;

/**
 *
 * @author usuario
 */
public class PaginaG {
    
    private int n;
    private int m;
    private int m1;
    private int cont;
    private int info[];
    private PaginaG[] apuntadores;
    private Rectangle r;
    private Label labels[];

    public PaginaG(int n, int info[], Rectangle r, Label[] l, int cont) {
        this.n=n;
        this.m=n*2;
        this.m1= (this.m)+1;
        this.info= info;
        this.apuntadores= new PaginaG[this.m1];
        this.r = r;
        this.labels = l;
        this.cont = cont;
    }

    public int getN() {
        return n;
    }

    public void setN(int n) {
        this.n = n;
    }

    public int getM() {
        return m;
    }

    public void setM(int m) {
        this.m = m;
    }

    public int getM1() {
        return m1;
    }

    public void setM1(int m1) {
        this.m1 = m1;
    }

    public int getCont() {
        return cont;
    }

    public void setCont(int cont) {
        this.cont = cont;
    }

    public int[] getInfo() {
        return info;
    }

    public void setInfo(int[] info) {
        this.info = info;
    }

    public PaginaG[] getApuntadores() {
        return apuntadores;
    }

    public void setApuntadores(PaginaG[] apuntadores) {
        this.apuntadores = apuntadores;
    }

    public Rectangle getR() {
        return r;
    }

    public void setR(Rectangle r) {
        this.r = r;
    }

    public Label[] getLabels() {
        return labels;
    }

    public void setLabels(Label[] labels) {
        this.labels = labels;
    }
    
    
    
}
