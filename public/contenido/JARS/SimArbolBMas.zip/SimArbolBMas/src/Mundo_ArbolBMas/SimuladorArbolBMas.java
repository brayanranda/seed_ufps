/**
 * ---------------------------------------------------------------------
 * $Id: SimuladorArbolBMas.java,v 1.0 2013/08/23 
 * Universidad Francisco de Paula Santander 
 * Programa Ingenieria de Sistemas
 *
 * Proyecto: SEED_UFPS
 * ----------------------------------------------------------------------
 */

package Mundo_ArbolBMas;

import Colecciones_SEED.ArbolBMas;
import Graficos.ArbolBMasG;
import java.util.Iterator;

/**
 * Clase que conecta la capa de presentación del Simulador con las Estructuras de Datos.
 * @author Uriel Garcia - Yulieth Pabon
 * @version 1.0
 */

public class SimuladorArbolBMas {
    
    private ArbolBMas<Integer> miArbolBMas;
    
    public SimuladorArbolBMas(){
    }
    
    public boolean crearArbol(int n){
        if(n<=0 || n>3)
            return (false);
        this.miArbolBMas = new ArbolBMas<Integer>(n);
        return (true);
    }
    
    public boolean existeArbol(){
        return (this.miArbolBMas!=null);
    }
    
    public ArbolBMasG crearArbolBGrafico(ArbolBMasG n) {        
        n.crearArbol(this.miArbolBMas.getRaiz());
        return (n);
    }

    public int conocerAltura() {
        return (this.miArbolBMas.getAltura());
    }

    
    public int insertarDato(int dato) {
        if(this.miArbolBMas.estaBMas(dato))
            return -1; //Dato repetido
        ArbolBMas<Integer> clon = this.miArbolBMas.clonar();
        if(clon.insertarBMas(dato)){
            if((clon.getAltura()>4&&clon.getN()==1) || (clon.getAltura()>3&&clon.getN()>1))
            return (-2);
            this.miArbolBMas.insertarBMas(dato);
            return 0; //Insercion correcta
        }
        return (-3);
        
    }
    
        public boolean estaVacioArbol() {
            return (this.miArbolBMas.esVacio());
        }
    
        public boolean eliminarDato(int dato) {
            if(!this.miArbolBMas.estaBMas(dato))
                return (false);
            return this.miArbolBMas.eliminarBMas(dato);
        }
    
        public boolean estaDatoenArbol(int dato) {
            return (this.miArbolBMas.estaBMas(dato));
        }
    
        public int contarHojas() {
            return (this.miArbolBMas.contarHojas());
        }
    
        
        public String obtenerHojas() {
            Iterator<Integer> it = this.miArbolBMas.getHojas();
            String cad = "";
            while(it.hasNext()){
                cad+= it.next();
                if(it.hasNext())
                    cad+=", ";
                else
                    cad+=".";
            }
            return (cad);
        }
    
        public void podarHojas() {
            this.miArbolBMas.podar();
        }
    
        public String recorridoPreorden() {
            Iterator<Integer> it = this.miArbolBMas.preOrden();
            String cad = "";
            int i=0;
            while(it.hasNext()){
                cad+= it.next().toString();
                if(it.hasNext())
                    cad+=", ";
                else
                    cad+=".";
                if(i==15){
                    cad+="\n";
                }
                i++;
            }
            return (cad);
        }
    
        public String recorridoInorden() {
            Iterator<Integer> it = this.miArbolBMas.inOrden();
            String cad = "";
            int i=0;
            while(it.hasNext()){
                cad+= it.next().toString();
                if(it.hasNext())
                    cad+=", ";
                else
                    cad+=".";
                if(i==15){
                    cad+="\n";
                }
                i++;
            }
            return (cad);
        }
    
        public String recorridoPostorden() {
            Iterator<Integer> it = this.miArbolBMas.postOrden();
            String cad = "";
            int i=0;
            while(it.hasNext()){
                cad+= it.next().toString();
                if(it.hasNext())
                    cad+=", ";
                else
                    cad+=".";
                if(i==15){
                    cad+="\n";
                }
                i++;
            }
            return (cad);
        }
    
        public String recorridoPorNiveles() {
            Iterator<Integer> it = this.miArbolBMas.impNiveles();
            String cad = "";
            int i=0;
            while(it.hasNext()){
                cad+= it.next().toString();
                if(it.hasNext())
                    cad+=", ";
                else
                    cad+=".";
                if(i==15){
                    cad+="\n";
                }
                i++;
            }
            return (cad);
        }
    
    public int conocerPeso() {
        return this.miArbolBMas.getPesoBMas();
    }
    
        
    public ArbolBMas getMiArbolB() {
        return miArbolBMas;
    }

    public void setMiArbolB(ArbolBMas miArbolBMas) {
        this.miArbolBMas = miArbolBMas;
    }

    public String impVSAM() {
        return this.miArbolBMas.listar_vsam();
    }

    public void limpiarArbol() {
        this.miArbolBMas.limpiarBMas();
    }
    
    


}
