/**
 * ---------------------------------------------------------------------
 * $Id: SimuladorArbolHeap.java,v 1.0 2013/08/23 
 * Universidad Francisco de Paula Santander 
 * Programa Ingenieria de Sistemas
 *
 * Proyecto: SEED_UFPS
 * ----------------------------------------------------------------------
 */

package Mundo_ArbolHeap;

import Colecciones_SEED.ArbolHeap;
import Graficos.ArbolHeapG;
import java.util.Iterator;

/**
 * Clase que conecta la capa de presentación del Simulador con las Estructuras de Datos.
 * @author Uriel Garcia - Yulieth Pabon
 * @version 1.0
 */

public class SimuladorArbolHeap {
    
    private ArbolHeap<Integer> miHeap;
    
    public SimuladorArbolHeap(){
        this.miHeap = new ArbolHeap<Integer>();
    }
    
    public ArbolHeapG crearArbolHeapGrafico(ArbolHeapG n) {
        Object heap[] = this.miHeap.getDatos();
        n.crearArbol(heap);
        return (n);
    }

    public int conocerAltura() {
        return this.miHeap.getAltura();
    }

    public int insertarDato(int dato) {
        if(this.miHeap.esta(dato))
            return -1; //Dato repetido
        if(this.miHeap.getPeso()+1==32)            
            return -2; //Supera la altura 5
        this.miHeap.insertar(dato);
        return 0; //Insercion correcta
    }

    public boolean estaVacioArbol() {
        return (this.miHeap.esVacio());
    }
    
    public int eliminarRaiz(){
        return (this.miHeap.eliminarRaiz());
    }

    public boolean eliminarDato(int dato) {
        return (this.miHeap.eliminar(dato)!=null);
    }

    public boolean estaDatoenArbol(int dato) {
        return (this.miHeap.esta(dato));
    }

    public int conocerPeso() {
        return (this.miHeap.getPeso());
    }

    public int contarHojas() {
        return (this.miHeap.contarHojas());
    }

    public String obtenerHojas() {
        Iterator<Integer> it = this.miHeap.getHojas();
        String cad = "";
        while(it.hasNext()){
            cad+= it.next().toString();
            if(it.hasNext())
                cad+=", ";
            else
                cad+=".";
        }        
        return (cad);
    }

    public void podarHojas() {
        this.miHeap.podar();
    }

    public String recorridoPreorden() {
        Iterator<Integer> it = this.miHeap.preOrden();
        String cad = "";
        int i=0;
        while(it.hasNext()){
            cad+= it.next().toString();
            if(it.hasNext())
                cad+=", ";
            else
                cad+=".";
            if(i==15){
                cad+="\n";
            }
            i++;
        }        
        return (cad);
    }
    
    public String recorridoInorden() {
        Iterator<Integer> it = this.miHeap.inOrden();
        String cad = "";
        int i=0;
        while(it.hasNext()){
            cad+= it.next().toString();
            if(it.hasNext())
                cad+=", ";
            else
                cad+=".";
            if(i==15){
                cad+="\n";
            }
            i++;
        }        
        return (cad);
    }
    
    public String recorridoPostorden() {
        Iterator<Integer> it = this.miHeap.postOrden();
        String cad = "";
        int i=0;
        while(it.hasNext()){
            cad+= it.next().toString();
            if(it.hasNext())
                cad+=", ";
            else
                cad+=".";
            if(i==15){
                cad+="\n";
            }
            i++;
        }        
        return (cad);
    }
    
    public String recorridoPorNiveles() {
        Iterator<Integer> it = this.miHeap.impNiveles();
        String cad = "";
        int i=0;
        while(it.hasNext()){
            cad+= it.next().toString();
            if(it.hasNext())
                cad+=", ";
            else
                cad+=".";
            if(i==15){
                cad+="\n";
            }
            i++;
        }        
        return (cad);
    }

    public String heapSort() {
        int p = this.miHeap.getPeso();
        Object v[] = this.miHeap.heapSort();
        String cad = "";
        for(int i=0; i<p; i++){
            cad+= v[i].toString()+" | ";
            if(i==15)
                cad+="\n";
        }
        cad+=".";
        return (cad);
    }

    public String impDatosHeap() {
        Object v[] = this.miHeap.getDatos();
        String cad = "";
        for(int i=0; i<this.miHeap.getPeso(); i++){
            cad+= v[i].toString()+" | ";
            if(i==15)
                cad+="\n";
        }
        cad+=".";
        return (cad);
    }

    public void vaciarArbol() {
        this.miHeap.limpiar();
    }
    
    
}
