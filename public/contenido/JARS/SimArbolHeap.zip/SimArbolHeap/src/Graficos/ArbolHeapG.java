/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Graficos;
/**
 *
 * @author usuario
 */
public class ArbolHeapG extends ArbolBinarioG{
    

    /**
     *
     */
    public ArbolHeapG() {
        super();
    }

   
    public void crearArbol(Object heap[]) {
        super.setRaiz(this.crear(heap,0));
    }
    
    private NodoBinG crear(Object[] heap, int i) {
        if(heap[i]==null)
            return (null);
        NodoBinG aux= new NodoBinG((int)heap[i],super.getPila().desapilar(),super.getLab().desapilar(),crear(heap,((2*i)+1)),crear(heap,((2*i)+2)));
        return (aux);
    }

}
