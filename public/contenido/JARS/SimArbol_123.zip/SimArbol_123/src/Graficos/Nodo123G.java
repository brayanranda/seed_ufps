/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Graficos;

import javafx.scene.control.Label;
import javafx.scene.shape.Rectangle;

/**
 *
 * @author usuario
 */
public class Nodo123G {
    
    private Rectangle r;
    private Label l1;
    private Label l2;
    private int infoMen;
    private int infoMay;
    private Nodo123G izq;
    private Nodo123G med;
    private Nodo123G der;

    public Nodo123G(int info1, int info2, Rectangle r, Label l1, Label l2, Nodo123G izq, Nodo123G med, Nodo123G der) {
        this.r = r;
        this.l1 = l1;
        this.l2 = l2;
        this.infoMen=info1;
        this.infoMay=info2;
        this.med = med;
        this.izq = izq;
        this.der = der;
        this.l1.setText(infoMen+"");
        this.l2.setText(infoMay+"");
    }

    public Rectangle getR() {
        return r;
    }

    public void setR(Rectangle r) {
        this.r = r;
    }

    public int getInfoMen() {
        return infoMen;
    }

    public void setInfoMen(int infoMen) {
        this.infoMen = infoMen;
    }

    public int getInfoMay() {
        return infoMay;
    }

    public void setInfoMay(int infoMay) {
        this.infoMay = infoMay;
    }
    
    

    public Nodo123G getIzq() {
        return izq;
    }

    public void setIzq(Nodo123G izq) {
        this.izq = izq;
    }

    public Nodo123G getMed() {
        return med;
    }

    public void setMed(Nodo123G med) {
        this.med = med;
    }

    public Nodo123G getDer() {
        return der;
    }

    public void setDer(Nodo123G der) {
        this.der = der;
    }

    public Label getL1() {
        return l1;
    }

    public void setL1(Label l1) {
        this.l1 = l1;
    }

    public Label getL2() {
        return l2;
    }

    public void setL2(Label l2) {
        this.l2 = l2;
    }

    

    
    
    
    
}
