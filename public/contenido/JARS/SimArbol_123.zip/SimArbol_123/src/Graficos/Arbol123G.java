/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Graficos;


import Colecciones_SEED.Cola;
import Colecciones_SEED.ListaCD;
import Colecciones_SEED.Nodo123;
import Colecciones_SEED.Pila;
import Graficos.Nodo123G;
import javafx.animation.KeyFrame;
import javafx.animation.KeyValue;
import javafx.animation.Timeline;
import javafx.scene.control.Label;
import javafx.scene.paint.Color;
import javafx.scene.shape.Line;
import javafx.scene.shape.Rectangle;
import javafx.util.Duration;

/**
 *
 * @author usuario
 */
public class Arbol123G {
    
    private Nodo123G raiz;
    private Pila<Rectangle> pila;
    private Pila<Label> lab;
    private Pila<Line> lin;

    public Arbol123G() {
        this.raiz = null;
        pila = new Pila();
        lab = new Pila();
        lin = new Pila();
    }

    public Nodo123G getRaiz() {
        return raiz;
    }

    public Pila<Rectangle> getPila() {
        return pila;
    }

    public void setPila(Pila<Rectangle> pila) {
        this.pila = pila;
    }
    
    

    public Pila<Label> getLab() {
        return lab;
    }

    public void setLab(Pila<Label> lab) {
        this.lab = lab;
    }

    public Pila<Line> getLin() {
        return lin;
    }

    public void setLin(Pila<Line> lin) {
        this.lin = lin;
    }

    public void setRaiz(Nodo123G raiz){
        this.raiz = raiz;
    }

    
    public void crearArbol(Nodo123 raiz) {
        this.setRaiz(crear(raiz));
    }
    
    private Nodo123G crear(Nodo123 r) {
        if(r==null)
            return (null);
        else
        {   
            Nodo123G aux=new Nodo123G((-100),(-100), this.pila.desapilar(), this.lab.desapilar(), this.lab.desapilar(), crear(r.getIzq()), crear(r.getMed()),crear(r.getDer()));
            Object infoMen = r.getInfoMen(), infoMay= r.getInfoMay();
            if(infoMen!=null)
                aux.setInfoMen((int)infoMen);
            if(infoMay!=null)
                aux.setInfoMay((int)infoMay);
            return (aux);
        }
    }

    public void cargarNodos(Rectangle[] nodos) {
        for(int i=0; i<nodos.length; i++)
            this.pila.apilar(nodos[i]);
    }

    public void cargarLabels(Label[] labels) {
        for(int i=0; i<labels.length; i++)
            this.lab.apilar(labels[i]);
    }

    public void cargarLineas(Line[] lineas) {
        for(int i=0; i<lineas.length; i++)
            this.lin.apilar(lineas[i]);
    }

    public void pintarArbol(int alt){
        if(this.raiz==null){
            Rectangle c = this.pila.desapilar();
            Label l1 = this.lab.desapilar();   
            Label l2 = this.lab.desapilar();
            c.setLayoutX(500.0);
            c.setLayoutY(180.0);
            l1.setLayoutX(500.0);
            l1.setLayoutY(180.0);
            l2.setLayoutX(512.5);
            l2.setLayoutY(180.0);
            c.setFill(Color.GRAY);
            c.setStroke(Color.BLACK);
            l1.setText("-"); 
            l2.setText("-");
            c.setVisible(true);
            l1.setVisible(true);
            l2.setVisible(true);
            return;
        }
        this.pinta(raiz,null,alt);
    }

    private void pinta(Nodo123G r, Nodo123G padre, int alt) {        
        Line l;     
        int ajuste = calculaAjuste(alt);
        if(r==null){
            return;
        }      
        r.getR().setVisible(true);
        r.getL1().setText(this.mostrarInfo(r.getInfoMen()));
        r.getL1().setTextFill(Color.BLUE);
        r.getL1().setVisible(true);  
        r.getL2().setText(this.mostrarInfo(r.getInfoMay()));
        r.getL2().setTextFill(Color.RED);
        r.getL2().setVisible(true); 
        if(padre==null){
            double lx = 500;
            r.getR().setLayoutX(lx);
            r.getR().setLayoutY(180.0);
            r.getL1().setLayoutX(lx);
            r.getL1().setLayoutY(180.0);
            r.getL1().setTextFill(Color.BLUE);
            r.getL2().setLayoutX(lx+12.5);
            r.getL2().setLayoutY(180.0);
            r.getL2().setTextFill(Color.RED);
            r.getR().setVisible(true);
            r.getL1().setText(this.mostrarInfo(r.getInfoMen()));
            r.getL1().setVisible(true);
            r.getL2().setText(this.mostrarInfo(r.getInfoMay()));
            r.getL2().setVisible(true);
        }
        if(r.getIzq()!=null){
            r.getIzq().getR().setLayoutX(r.getR().getLayoutX()-(25*ajuste));
            r.getIzq().getR().setLayoutY(r.getR().getLayoutY()+70.0);
            r.getIzq().getL1().setLayoutX(r.getL1().getLayoutX()-(25*ajuste));
            r.getIzq().getL1().setLayoutY(r.getL1().getLayoutY()+70.0);
            r.getIzq().getL2().setLayoutX(r.getL2().getLayoutX()-(25*ajuste));
            r.getIzq().getL2().setLayoutY(r.getL2().getLayoutY()+70.0);
            r.getIzq().getR().setVisible(true);
            r.getIzq().getL1().setText(this.mostrarInfo(r.getInfoMen()));
            r.getIzq().getL1().setTextFill(Color.BLUE);
            r.getIzq().getL1().setVisible(true);  
            r.getIzq().getL2().setText(this.mostrarInfo(r.getInfoMay()));
            r.getIzq().getL2().setTextFill(Color.RED);
            r.getIzq().getL2().setVisible(true); 
            l = lin.desapilar();            
            l.setLayoutX(r.getR().getLayoutX());
            l.setLayoutY(r.getR().getLayoutY());
            l.setStartX(0);
            l.setEndX((-(25*ajuste))+12.5);
            l.setStartY(20.0);
            l.setEndY(70.0);
            l.setVisible(true);
            
        }
        if(r.getMed()!=null){
            r.getMed().getR().setLayoutX(r.getR().getLayoutX());
            r.getMed().getR().setLayoutY(r.getR().getLayoutY()+70.0);
            r.getMed().getL1().setLayoutX(r.getL1().getLayoutX());
            r.getMed().getL1().setLayoutY(r.getL1().getLayoutY()+70.0);
            r.getMed().getL2().setLayoutX(r.getL2().getLayoutX());
            r.getMed().getL2().setLayoutY(r.getL2().getLayoutY()+70.0);
            r.getMed().getR().setVisible(true);
            r.getMed().getL1().setText(this.mostrarInfo(r.getInfoMen()));
            r.getMed().getL1().setTextFill(Color.BLUE);
            r.getMed().getL1().setVisible(true);
            r.getMed().getL2().setText(this.mostrarInfo(r.getInfoMay()));
            r.getMed().getL2().setTextFill(Color.RED);
            r.getMed().getL2().setVisible(true);
            l = this.lin.desapilar();                        
            l.setLayoutX(r.getR().getLayoutX());
            l.setLayoutY(r.getR().getLayoutY());
            l.setStartX(12.5);
            l.setEndX(12.5);
            l.setStartY(20.0);
            l.setEndY(70.0);
            l.setVisible(true);            
        }
        if(r.getDer()!=null){
            r.getDer().getR().setLayoutX(r.getR().getLayoutX()+(25*ajuste));
            r.getDer().getR().setLayoutY(r.getR().getLayoutY()+70.0);
            r.getDer().getL1().setLayoutX(r.getL1().getLayoutX()+(25*ajuste));
            r.getDer().getL1().setLayoutY(r.getL1().getLayoutY()+70.0);
            r.getDer().getL2().setLayoutX(r.getL2().getLayoutX()+(25*ajuste));
            r.getDer().getL2().setLayoutY(r.getL2().getLayoutY()+70.0);
            r.getDer().getR().setVisible(true);
            r.getDer().getL1().setText(this.mostrarInfo(r.getInfoMen()));
            r.getDer().getL1().setTextFill(Color.BLUE);
            r.getDer().getL1().setVisible(true);
            r.getDer().getL2().setText(this.mostrarInfo(r.getInfoMay()));
            r.getDer().getL2().setTextFill(Color.RED);
            r.getDer().getL2().setVisible(true);
            l = this.lin.desapilar();                        
            l.setLayoutX(r.getR().getLayoutX());
            l.setLayoutY(r.getR().getLayoutY());
            l.setStartX(25.0);
            l.setEndX((25*ajuste)+12.5);
            l.setStartY(20.0);
            l.setEndY(70.0);
            l.setVisible(true);            
        }        
        pinta(r.getIzq(),r,alt-1);
        pinta(r.getMed(),r,alt-1);
        pinta(r.getDer(),r,alt-1);
    }

    private int calculaAjuste(int ajuste) {
        switch(ajuste){
            case 1: return (1);
            case 2: return (1);
            case 3: return (3);
            case 4: return (9); 
        }
        return (-1);
    }

   public void animacion(int i, int dato, Timeline tl) {
        this.reajustarColores();
        tl = new Timeline();
        tl.setCycleCount(1);
        tl.getKeyFrames().removeAll();
        switch(i){
            //Insertar 0
            case 0:
                this.pintarInsertado(dato, tl);
                break;
            //Eliminar 1
            case 1:                
                break;
            //Buscar 2
            case 2:
                this.buscarG(dato, tl);
                break;
            //Hojas 3
            case 3:
                this.getHojas();
                break;
            //Podar 4
            case 4:
                this.getHojas();
                break;
            // preorden 5
            case 5:
                this.preOrden(tl);
                break;
            // inorden 6
            case 6:
                this.inOrden(tl);
                break;
            //postorden 7
            case 7:
                this.postOrden(tl);
                break;
            //niveles 8
            case 8:
                this.impNiveles(tl);
                break;
        }
    }
    
    /**
     *
     * @param dato
     * @param tl
     */
    public void pintarInsertado(int dato, Timeline tl){
        double durac = 0;
        Nodo123G n = this.buscar(getRaiz(), dato);
        if(n!=null){
            tl.getKeyFrames().setAll(
            new KeyFrame(new Duration(durac), new KeyValue(n.getR().strokeProperty(),Color.BLACK)),
            new KeyFrame(new Duration((durac+1000)), new KeyValue(n.getR().strokeProperty(),Color.RED)),
            new KeyFrame(new Duration(durac), new KeyValue(n.getR().fillProperty(),Color.WHITE)),
            new KeyFrame(new Duration((durac+1000)), new KeyValue(n.getR().fillProperty(),Color.BEIGE)));
            tl.play();
        }
    }
    
    private Nodo123G buscar(Nodo123G r, int dato) {
        if(r==null)
            return (null);
        int comp1=0, comp2=0;
        boolean hayInfoI=false, hayInfoF=false;
        //Si existe el InfoMenor
        if(r.getInfoMen()!=(-100)){
            hayInfoI = true;
            comp1 = ((Comparable)dato).compareTo(r.getInfoMen());
        }
        //Si existe el InfoMAyor
        if(r.getInfoMay()!=(-100)){
            hayInfoF = true;
            comp2 = ((Comparable)dato).compareTo(r.getInfoMay());
        }         
        if((hayInfoI&&comp1==0) || (hayInfoF&&comp2==0))
            return (r);     
        //Buscar por la izquierda
        if(hayInfoI&&comp1<0){
            if(r.getIzq()==null)
                return (null);
            return (this.buscar(r.getIzq(),dato));
        }
        //Buscar por el medio
        if(hayInfoF&&comp2<0){
            if(r.getMed()==null)
                return (null);
            return (this.buscar(r.getMed(), dato));
        }
        //Buscar por la derecha
        if(r.getDer()!=null)            
        return (this.buscar(r.getDer(), dato));
        //El objeto no ha sido encontrado
        return (null);
    }

    
    /**
     *
     * @param x
     * @param tl
     * @return
     */
    public boolean buscarG(int x, Timeline tl){
        ListaCD<Nodo123G> l=new ListaCD<Nodo123G>();
        if(this.getRaiz()==null)
            return (false);
        boolean rta = this.buscarG(getRaiz(), x, l);
        int durac = 0;
        for(int i=0; i<l.getTamanio(); i++){
            Nodo123G n = l.get(i);
            tl.getKeyFrames().addAll(new KeyFrame(new Duration(durac), new KeyValue(n.getR().strokeProperty(),Color.BLACK)),
            new KeyFrame(new Duration((durac+1000)), new KeyValue(n.getR().strokeProperty(),Color.RED)));
            tl.getKeyFrames().addAll(new KeyFrame(new Duration(durac), new KeyValue(n.getR().fillProperty(),Color.WHITE)),
            new KeyFrame(new Duration((durac+1000)), new KeyValue(n.getR().fillProperty(),Color.BEIGE)));
            durac+=1000;
        }
        tl.play();
        return (rta);
    }
    
    private boolean buscarG(Nodo123G r, int dato, ListaCD<Nodo123G> l){
        int comp1=0, comp2=0;
        boolean hayInfoI=false, hayInfoF=false;
        //Existe el InfoMenor
        l.insertarAlFinal(r);
        if(r.getInfoMen()!=(-100)){
            hayInfoI = true;
            comp1 = ((Comparable)dato).compareTo(r.getInfoMen());
        }
        //Existe el InfoMayor
        if(r.getInfoMay()!=(-100)){
            hayInfoF = true;
            comp2 = ((Comparable)dato).compareTo(r.getInfoMay());
        } 
        if((hayInfoI&&comp1==0) || (hayInfoF&&comp2==0))
            return (true);   
        //Busca por izquierda
        if(hayInfoI&&comp1<0){
            if(r.getIzq()==null)
                return (false);
            return (this.buscarG(r.getIzq(),dato,l));
        }
        //Busca por el medio
        if(hayInfoF&&comp2<0){
            if(r.getMed()==null)
                return (false);
            return (this.buscarG(r.getMed(), dato,l));
        }
        //Busca por la derecha
        if(r.getDer()!=null)            
        return (this.buscarG(r.getDer(), dato,l));
        //El objeto no ha sido encontrado
        return (false);
    }
    
    /**
     *
     */
    public void reajustarColores(){
        this.reajustarColores(raiz);
    }
    
    private void reajustarColores(Nodo123G r){
        if(r==null){
            return;
        }
        r.getR().setFill(Color.WHITE);
        r.getR().setStroke(Color.BLACK);
        reajustarColores(r.getIzq());
        reajustarColores(r.getDer());
    }

    private String mostrarInfo(int info) {
        if(info==(-100))
            return "-";
        return (info+"");
    }
    
    public String getLayoutsEliminar(int dato) {
        Nodo123G n = this.buscar(raiz, dato);
        double lx1=0, lx2=0, lx3=0, lx4=0, lx5=0, lx6=0;
        if(n!=null){            
            lx1 = n.getR().getLayoutX();
            lx2 = n.getR().getLayoutY();
            lx3 = n.getL1().getLayoutX();
            lx4 = n.getL1().getLayoutY();
            lx5 = n.getL2().getLayoutX();
            lx6 = n.getL2().getLayoutY();
        }  
        int es= dato==this.raiz.getInfoMen()?0:1;
        return (lx1+"_"+lx2+"_"+lx3+"_"+lx4+"_"+lx5+"_"+lx6+"_"+es);
    }   

    public void animacionEliminar(String layouts, int dato, Timeline tl, Rectangle r, Label l) {
        tl = new Timeline();
        tl.setCycleCount(1);
        tl.getKeyFrames().removeAll();
        String v[] = layouts.split("_");
        r.setLayoutX(Double.parseDouble(v[0]));
        r.setLayoutY(Double.parseDouble(v[1]));
        //pasa saber cual dato fue eliminado.
        if((Integer.parseInt(v[6]))==0){
            l.setLayoutX(Double.parseDouble(v[2])+12.5);
            l.setLayoutY(Double.parseDouble(v[3]));
        }else{
            l.setLayoutX(Double.parseDouble(v[4])-12.5);
            l.setLayoutY(Double.parseDouble(v[5]));
        }
        l.setText(dato+"");
        r.setVisible(true);
        l.setVisible(true);
        
        tl.getKeyFrames().addAll(new KeyFrame(new Duration(0), new KeyValue(r.strokeProperty(),Color.BLACK)),
        new KeyFrame(new Duration(2000), new KeyValue(r.strokeProperty(),Color.RED)));
        tl.getKeyFrames().addAll(new KeyFrame(new Duration(0), new KeyValue(r.fillProperty(),Color.WHITE)),
        new KeyFrame(new Duration(2000), new KeyValue(r.fillProperty(),Color.BEIGE)));            
        tl.getKeyFrames().addAll(new KeyFrame(new Duration(0), new KeyValue(r.translateYProperty(),0)),
        new KeyFrame(new Duration(3000), new KeyValue(r.translateYProperty(),400-r.getLayoutY())));            
        tl.getKeyFrames().addAll(new KeyFrame(new Duration(0), new KeyValue(l.translateYProperty(),0)),
        new KeyFrame(new Duration(3000), new KeyValue(l.translateYProperty(),400-l.getLayoutY())));            
        tl.getKeyFrames().addAll(new KeyFrame(new Duration(2000), new KeyValue(r.visibleProperty(),true)),
        new KeyFrame(new Duration(3000), new KeyValue(r.visibleProperty(),false)));            
        tl.getKeyFrames().addAll(new KeyFrame(new Duration(2000), new KeyValue(l.visibleProperty(),true)),
        new KeyFrame(new Duration(3000), new KeyValue(l.visibleProperty(),false)));                  
        
        tl.play();
    }

    public boolean eraInfoUnica(int dato) {
        Nodo123G r = this.buscar(this.raiz, dato);
        return (r.getInfoMen()==(-100) || r.getInfoMay()==(-100));
    }

    public void getHojas(){
        getHojas(raiz);
    }
    
    private void getHojas(Nodo123G r){
        if (r!=null){
            if(this.esHoja(r)){
                r.getR().setFill(Color.BEIGE);
                r.getR().setStroke(Color.RED);
            }
            getHojas(r.getIzq());
            getHojas(r.getMed());
            getHojas(r.getDer());
        }
    }
    
    private boolean esHoja(Nodo123G x){
        return (x!=null && x.getIzq()==null && x.getMed()==null && x.getDer()==null);
    }

    /**
     *
     * @param tl
     */
    public void preOrden(Timeline tl){
        int durac =0;
        ListaCD<Nodo123G> l=new ListaCD<Nodo123G>();
         preOrden(this.getRaiz(),l);
        for(int i=0; i<l.getTamanio(); i++){
            Nodo123G n = l.get(i);
            tl.getKeyFrames().addAll(new KeyFrame(new Duration(durac), new KeyValue(n.getR().strokeProperty(),Color.BLACK)),
            new KeyFrame(new Duration((durac+1000)), new KeyValue(n.getR().strokeProperty(),Color.RED)));
            tl.getKeyFrames().addAll(new KeyFrame(new Duration(durac), new KeyValue(n.getR().fillProperty(),Color.WHITE)),
            new KeyFrame(new Duration((durac+1000)), new KeyValue(n.getR().fillProperty(),Color.BEIGE)));
            durac+=1000;
        }
        tl.play();
    }

    private void  preOrden(Nodo123G r, ListaCD<Nodo123G> l){
        if(r!=null){
            l.insertarAlFinal(r);
            preOrden(r.getIzq(), l);
            preOrden(r.getMed(), l);
            preOrden(r.getDer(), l);
        }
    }
    
    /**
     *
     * @param tl
     */
    public void inOrden(Timeline tl){
        int durac =0;
        ListaCD<Nodo123G> l=new ListaCD<Nodo123G>();
         inOrden(this.getRaiz(),l);
        for(int i=0; i<l.getTamanio(); i++){
            Nodo123G n = l.get(i);
            tl.getKeyFrames().addAll(new KeyFrame(new Duration(durac), new KeyValue(n.getR().strokeProperty(),Color.BLACK)),
            new KeyFrame(new Duration((durac+1000)), new KeyValue(n.getR().strokeProperty(),Color.RED)));
            tl.getKeyFrames().addAll(new KeyFrame(new Duration(durac), new KeyValue(n.getR().fillProperty(),Color.WHITE)),
            new KeyFrame(new Duration((durac+1000)), new KeyValue(n.getR().fillProperty(),Color.BEIGE)));
            durac+=1000;
        }
        tl.play();
    }

    private void  inOrden(Nodo123G r, ListaCD<Nodo123G> l){
        if(r!=null){
            inOrden(r.getIzq(), l);
            l.insertarAlFinal(r);
            inOrden(r.getMed(), l);
            inOrden(r.getDer(), l);
        }
    }

   
    /**
     *
     * @param tl
     */
    public void postOrden(Timeline tl){
        int durac =0;
        ListaCD<Nodo123G> l=new ListaCD<Nodo123G>();
         postOrden(this.getRaiz(),l);
        for(int i=0; i<l.getTamanio(); i++){
            Nodo123G n = l.get(i);
            tl.getKeyFrames().addAll(new KeyFrame(new Duration(durac), new KeyValue(n.getR().strokeProperty(),Color.BLACK)),
            new KeyFrame(new Duration((durac+1000)), new KeyValue(n.getR().strokeProperty(),Color.RED)));
            tl.getKeyFrames().addAll(new KeyFrame(new Duration(durac), new KeyValue(n.getR().fillProperty(),Color.WHITE)),
            new KeyFrame(new Duration((durac+1000)), new KeyValue(n.getR().fillProperty(),Color.BEIGE)));
            durac+=1000;
        }
        tl.play();
    }
    
    private void postOrden(Nodo123G r, ListaCD<Nodo123G> l){
        if(r!=null){
            postOrden(r.getIzq(), l);
            postOrden(r.getMed(), l);
            postOrden(r.getDer(), l);
            l.insertarAlFinal(r);
        }
    }
    
    /**
     *
     * @param tl
     */
    public void impNiveles(Timeline tl){
        int durac =0;
        ListaCD<Nodo123G> l=new ListaCD<Nodo123G>();
        this.impNiveles(l);
        for(int i=0; i<l.getTamanio(); i++){
            Nodo123G n = l.get(i);
            tl.getKeyFrames().addAll(new KeyFrame(new Duration(durac), new KeyValue(n.getR().strokeProperty(),Color.BLACK)),
            new KeyFrame(new Duration((durac+1000)), new KeyValue(n.getR().strokeProperty(),Color.RED)));
            tl.getKeyFrames().addAll(new KeyFrame(new Duration(durac), new KeyValue(n.getR().fillProperty(),Color.WHITE)),
            new KeyFrame(new Duration((durac+1000)), new KeyValue(n.getR().fillProperty(),Color.BEIGE)));
            durac+=1000;
        }
        tl.play();
    }
    
    
    private void impNiveles(ListaCD<Nodo123G> l){        
        if(!this.esVacio()){
            Cola<Nodo123G> c=new Cola<>();
            c.enColar(this.getRaiz());
            Nodo123G x;
                while(!c.esVacia()){
                    x=c.deColar();
                    l.insertarAlFinal(x);
                    if(x.getIzq()!=null)
                    c.enColar(x.getIzq());
                    if(x.getMed()!=null)
                    c.enColar(x.getMed());
                    if(x.getDer()!=null)
                    c.enColar(x.getDer());
                }
        }
    }
    
    /**
     *
     * @return
     */
    public boolean esVacio(){
          return(this.raiz==null);
    }

    

    
}
