/**
 * ---------------------------------------------------------------------
 * $Id: SimuladorArbol1-2-3.java,v 1.0 2013/08/23 
 * Universidad Francisco de Paula Santander 
 * Programa Ingenieria de Sistemas
 *
 * Proyecto: SEED_UFPS
 * ----------------------------------------------------------------------
 */

package Mundo_Arbol123;

import Colecciones_SEED.Arbol123;
import Graficos.Arbol123G;
import java.util.Iterator;

/**
 * Clase que conecta la capa de presentación del Simulador con las Estructuras de Datos.
 * @author Uriel Garcia - Yulieth Pabon
 * @version 1.0
 */

public class SimuladorArbol123 {
    
    private Arbol123 miArbol123;
    
    public SimuladorArbol123(){
        this.miArbol123 = new Arbol123();
    }
    
    public Arbol123G crearArbol123Grafico(Arbol123G n) {
        n.crearArbol(this.miArbol123.getRaiz());
        return (n);
    }

    public int conocerAltura() {
        return this.miArbol123.getAltura();
    }

    public int insertarDato(int dato) {
        if(this.miArbol123.esta(dato))
            return -1; //Dato repetido
        if(this.miArbol123.insertar(dato)){
            if(this.miArbol123.getAltura()>4){
                this.miArbol123.eliminar(dato);
                return -2; //Supera la altura 5
            }
            return 0; //Insercion correcta
        }
        return -3; //No se pudo insertar
    }

    public boolean estaVacioArbol() {
        return (this.miArbol123.esVacio());
    }

    public boolean eliminarDato(int dato) {
        return (this.miArbol123.eliminar(dato));
    }

    public boolean estaDatoenArbol(int dato) {
        return (this.miArbol123.esta(dato));
    }

    public int contarHojas() {
        return (this.miArbol123.contarHojas());
    }

    public String obtenerHojas() {
        Iterator<Integer> it = this.miArbol123.getHojas();
        String cad = "";
        while(it.hasNext()){
            cad+= it.next().toString();
            if(it.hasNext())
                cad+=", ";
            else
                cad+=".";
        }        
        return (cad);
    }

    public void podarHojas() {
        this.miArbol123.podar();
    }
    
    public String recorridoPreorden() {
        Iterator<Integer> it = this.miArbol123.preOrden();
        String cad = "";
        int i=0;
        while(it.hasNext()){
            cad+= it.next().toString();
            if(it.hasNext())
                cad+=", ";
            else
                cad+=".";
            if(i==15){
                cad+="\n";
            }
            i++;
        }        
        return (cad);
    }
    
    public String recorridoInorden() {
        Iterator<Integer> it = this.miArbol123.inOrden();
        String cad = "";
        int i=0;
        while(it.hasNext()){
            cad+= it.next().toString();
            if(it.hasNext())
                cad+=", ";
            else
                cad+=".";
            if(i==15){
                cad+="\n";
            }
            i++;
        }        
        return (cad);
    }
    
    public String recorridoPostorden() {
        Iterator<Integer> it = this.miArbol123.postOrden();
        String cad = "";
        int i=0;
        while(it.hasNext()){
            cad+= it.next().toString();
            if(it.hasNext())
                cad+=", ";
            else
                cad+=".";
            if(i==15){
                cad+="\n";
            }
            i++;
        }        
        return (cad);
    }
    
    public String recorridoPorNiveles() {
        Iterator<Integer> it = this.miArbol123.impNiveles();
        String cad = "";
        int i=0;
        while(it.hasNext()){
            Integer obj = it.next();
            if(obj!=null){
                cad+= obj.toString();
                if(it.hasNext())
                    cad+=", ";
                else
                    cad+=".";
                if(i==15){
                    cad+="\n";
                }
                i++;
            }                
        }        
        return (cad);
    }

    public int conocerPeso() {
        return this.miArbol123.getPeso();
    }
    
    
    
}
