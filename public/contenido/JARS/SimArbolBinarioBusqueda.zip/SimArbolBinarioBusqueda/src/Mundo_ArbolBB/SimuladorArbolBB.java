/**
 * ---------------------------------------------------------------------
 * $Id: SimuladorArbolBB.java,v 1.0 2013/08/23 
 * Universidad Francisco de Paula Santander 
 * Programa Ingenieria de Sistemas
 *
 * Proyecto: SEED_UFPS
 * ----------------------------------------------------------------------
 */

package Mundo_ArbolBB;

import Graficos.ArbolBBG;
import Colecciones_SEED.ArbolBinarioBusqueda;
import java.util.Iterator;

/**
 * Clase que conecta la capa de presentación del Simulador con las Estructuras de Datos.
 * @author Uriel Garcia - Yulieth Pabon
 * @version 1.0
 */

public class SimuladorArbolBB {
    
    private ArbolBinarioBusqueda miAbb;
    
    public SimuladorArbolBB(){
        this.miAbb = new ArbolBinarioBusqueda();
    }
    
    public ArbolBBG crearArbolBinarioGrafico(ArbolBBG n) {
        n.crearArbol(this.miAbb.getRaiz());
        return (n);
    }

    public int conocerAltura() {
        return this.miAbb.getAltura();
    }

    public int insertarDato(int dato) {
        if(this.miAbb.estaABB(dato))
            return -1; //Dato repetido
        if(this.miAbb.insertar(dato)){
            if(this.miAbb.getAltura()>5){
                this.miAbb.eliminar(dato);
                return -2; //Supera la altura 5
            }
            return 0; //Insercion correcta
        }
        return -3; //No se pudo insertar
    }

    public boolean estaVacioArbol() {
        return (this.miAbb.esVacio());
    }

    public boolean eliminarDato(int dato) {
        return (this.miAbb.eliminar(dato));
    }

    public boolean estaDatoenArbol(int dato) {
        return (this.miAbb.estaABB(dato));
    }

    public int conocerPeso() {
        return (this.miAbb.getPeso());
    }

    public int contarHojas() {
        return (this.miAbb.contarHojas());
    }

    public String obtenerHojas() {
        Iterator<Integer> it = this.miAbb.getHojas();
        String cad = "";
        while(it.hasNext()){
            cad+= it.next().toString();
            if(it.hasNext())
                cad+=", ";
            else
                cad+=".";
        }        
        return (cad);
    }

    public void podarHojas() {
        this.miAbb.podar();
    }

    public String recorridoPreorden() {
        Iterator<Integer> it = this.miAbb.preOrden();
        String cad = "";
        int i=0;
        while(it.hasNext()){
            cad+= it.next().toString();
            if(it.hasNext())
                cad+=", ";
            else
                cad+=".";
            if(i==15){
                cad+="\n";
            }
            i++;
        }        
        return (cad);
    }
    
    public String recorridoInorden() {
        Iterator<Integer> it = this.miAbb.inOrden();
        String cad = "";
        int i=0;
        while(it.hasNext()){
            cad+= it.next().toString();
            if(it.hasNext())
                cad+=", ";
            else
                cad+=".";
            if(i==15){
                cad+="\n";
            }
            i++;
        }        
        return (cad);
    }
    
    public String recorridoPostorden() {
        Iterator<Integer> it = this.miAbb.postOrden();
        String cad = "";
        int i=0;
        while(it.hasNext()){
            cad+= it.next().toString();
            if(it.hasNext())
                cad+=", ";
            else
                cad+=".";
            if(i==15){
                cad+="\n";
            }
            i++;
        }        
        return (cad);
    }
    
    public String recorridoPorNiveles() {
        Iterator<Integer> it = this.miAbb.impNiveles();
        String cad = "";
        int i=0;
        while(it.hasNext()){
            cad+= it.next().toString();
            if(it.hasNext())
                cad+=", ";
            else
                cad+=".";
            if(i==15){
                cad+="\n";
            }
            i++;
        }        
        return (cad);
    }
    
}
