/**
 * ---------------------------------------------------------------------
 * $Id: SimuladorSecuencia.java,v 1.0 2013/08/23 
 * Universidad Francisco de Paula Santander 
 * Programa Ingenieria de Sistemas
 *
 * Proyecto: SEED_UFPS
 * ----------------------------------------------------------------------
 */

package Mundo_Secuencia;

import Colecciones_SEED.Secuencia;

/**
 * Clase que conecta la capa de presentación del Simulador con las Estructuras de Datos.
 * @author Uriel Garcia - Yulieth Pabon
 * @version 1.0
 */
public class SimuladorSecuencia {
    
    private Secuencia<Integer> miSecuencia;
    
    public SimuladorSecuencia(){
    }
    
    public void crearSecuencia(int tam){
        this.miSecuencia = new Secuencia<Integer>(tam);
    }
    
    public String impSecuencia(){
        String cad = "";
        for(int i=0; i<miSecuencia.getTamanio();i++){            
            cad+=this.miSecuencia.get(i)+"_";
        }
        return (cad);
    }
    
    public int conocerCapacidad(){
        return (this.miSecuencia.getCapacidad());
    }
    
    public boolean puedeInsertar() {
        return (this.miSecuencia.getTamanio()<this.miSecuencia.getCapacidad());
    }
    
    public boolean insertar(int dato) {
        if(this.miSecuencia.esta(dato))
            return (false);
        this.miSecuencia.insertar(dato);
        return (true);
    }
    
    public boolean esVacia(){
        return (this.miSecuencia.esVacia());
    }
    
    public boolean eliminar(int dato) {
        if(!this.miSecuencia.esta(dato))
            return (false);
        this.miSecuencia.eliminar(dato);
        return (true);
    }
    
    public int conocerTamanio() {
        return (this.miSecuencia.getTamanio());
    }
    
    public int obtenerElemento(int posi) {
        if(posi<0 || posi>=this.miSecuencia.getTamanio())
            return (-100);
        return (this.miSecuencia.get(posi));
    }
    
    public int obtenerIndice(int val) {
        return (this.miSecuencia.getIndice(val));
    }
    
    public int editar(int posi, int dato) {
        if(posi>=this.miSecuencia.getTamanio() || posi<0)
            return (-2);
        if(this.miSecuencia.esta(dato))
            return (-1);
        this.miSecuencia.set(posi, dato);
        return (0);
    }
    
    public Secuencia<Integer> getMiSecuencia() {
        return miSecuencia;
    }

    public void setMiSecuencia(Secuencia<Integer> miSecuencia) {
        this.miSecuencia = miSecuencia;
    }
   
    
}
